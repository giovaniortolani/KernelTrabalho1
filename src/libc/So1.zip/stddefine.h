#ifndef _DEFINE_H_
#define _DEFINE_H_

#define null ( (void*) 0)

#define size_tam long unsigned int

#endif
