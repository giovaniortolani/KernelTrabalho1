#ifndef _STRING_H_
#define _STRING_H_

#include "stddefine.h"

size_tam strtam(const char* str1);

char* strcopy(char*, const char*);

int strcomp(const char*, const char*);

void memcopy(void*, const void*, size_tam);

#endif
