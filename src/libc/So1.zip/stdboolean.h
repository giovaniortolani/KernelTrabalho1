#ifndef _BOOLEAN_H_
#define _BOOLEAN_H_

#define boolean int

#define true 1

#define false 0

#endif
