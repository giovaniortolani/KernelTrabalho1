#include "str.h"
#include "stddefine.h"
#include "stdboolean.h"
#include <stdio.h>


int main(int argc, char** argv){
	char str1[6];
	char str2[6];

	str1[0] = 'r';
	str1[1] = 'e';
	str1[2] = 'n';
	str1[3] = 'a';
	str1[4] = 'n';
	str1[5] = '\0';

	str2[0] = 'l';
	str2[1] = 'u';
	str2[2] = 'a';
	str2[3] = 'n';
	str2[4] = 'a';
	str2[5] = '\0';

	printf("SIZE1 = %d\n", (int)strtam(str1));
	printf("SIZE2 = %d\n", (int)strtam(str2));
	printf("COMP = %d\n", strcomp(str1, str2));
	printf("COPY = %s\n", strcopy(str1, str2));

	return 0;
}
