#include <string.h>
#include "stddefine.h"

size_tam strtam(const char* str){
	int size = 0;

	while(*str != '\0'){
		str++;
		size++;
	}

	return (size_tam)size;
}


char* strcopy(char* str1, const char* str2){
	size_tam size = strtam(str2);
	int i = 0;
	
	while(i != (int)size){
		str1[i] = str2[i];
		i++;
	}

	return str1;
}


int strcomp(const char* str1, const char* str2){
	if(strtam(str1) == strtam(str2)){
		while(*str1 && *str2){
			if(*str1 != *str2){
				if(*str1 < *str2) return 1;
				else return -1;			
			}

			*str1++;
			*str2++;
		}

		return 0;
	}

	else if(strtam(str1) > strtam(str2)) return 1;

	return -1;	
}

/*sem testar*/
void memcopy(void* str1, const void* str2, size_tam num){
	char* fim = (char*)str1;	
	char* ini = (char*)str2;

	while(num){
		*fim = *ini;
		
		*fim++;
		*ini++;
		num--;
	}	
}
